
import java.util.ArrayList;
import java.util.EmptyStackException;

public class CleanRoom {
	public ArrayList<String> stack = new ArrayList<String>();
	
	
	public void push (String j) {
		stack.add(j);
	}
	
	public int size() {
		return stack.size();
	}
	
	public String pop() {
		if (stack.isEmpty()) {
			throw new EmptyStackException();
		}
		return stack.remove(stack.size()-1);
	}
	
	public boolean isEmpty() {
		return stack.isEmpty();
	}
	
	public String firstOne() {
		if(stack.isEmpty()) {
			return "Hehe!!You are free!!";
		}
		
		return "You need to " + stack.get(stack.size()-1);
	
	
	
	}
	
	
	
	

}
