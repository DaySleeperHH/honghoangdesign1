
public class main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CleanRoom todo = new CleanRoom();
		
		//first found 3 jobs//
		todo.push("Put Away Laundry");
		todo.push("Empty Junk In Laundry Basket");
		todo.push("Clean Mold Food");
		System.out.println( todo.firstOne());
		
		//suddenly found another one//
		todo.push("Find the Mob");
		System.out.println( todo.firstOne());
		
		//do job and check//
		todo.pop();
		todo.pop();
		todo.pop();
		System.out.println(todo.firstOne());
		
		//finish final job and check//
		todo.pop();
		System.out.println(todo.firstOne());
	}

}
